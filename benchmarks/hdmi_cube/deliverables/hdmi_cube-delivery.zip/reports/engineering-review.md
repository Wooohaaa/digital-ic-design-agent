# Engineering review: hdmi_cube

Scope: fpga; artifact ready: True; engineering signoff: not granted.

| Gate | Owner | Status | Finding |
|---|---|---|---|
| SPEC-001 | requirements | blocked | Missing specification: spec/brief.md, spec/design.md |
| DV-001 | verification | pass | pass |
| DV-002 | verification | blocked | 7 runtime checks mapped to 0 planned requirements. |
| DV-003 | verification | blocked | RTL and testbench share the generation path; independent verification has not been established. |
| RTL-001 | design | blocked | Current strict RTL lint evidence is missing, stale or failing. |
| RTL-002 | design | review_required | Clock/reset-domain crossings, reset release and timing exceptions require engineering review. |
| IMPL-001 | implementation | pass | pass |
| IMPL-002 | implementation | review_required | Tool-reported STA coverage: 99.88%. Coverage and unconstrained paths require review; WNS alone does not establish complete timing constraints. |
| BOARD-001 | integration | review_required | Board revision and schematic confirmation not recorded. |
| DV-004 | verification | not_run | Code/toggle coverage, formal properties/equivalence and post-route simulation are not evidenced by this flow. |
| HW-001 | integration | not_run | Physical board programming and measurement have not been performed. |

## Next actions

- Record original requirements, assumptions and acceptance criteria.
- Create spec/verification-plan.json and execute every CHECK REQ-NNN PASS assertion.
- Review the verification plan and supply an independent reference/checker.
- Install Verilator if unavailable, run /lint, and fix warnings.
- Review clock/reset domains and exceptions; run CDC/RDC analysis for crossings.
- Inspect unconstrained endpoints, clocks and IO delays; document and review every timing exception.
- Confirm device, board revision, pinout, oscillator and IO voltages against the actual schematic.
- Select required analyses in the verification plan and collect tool-produced evidence.
- Program the board and record observed outputs against the hardware acceptance procedure.
