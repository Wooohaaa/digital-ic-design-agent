import asyncio
import json
import shutil
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from textual.widgets import Input

from fpga_agent.project import create_project
from fpga_agent.terminal import TaskPlan, read_json
from fpga_agent.tui import Connection, ForgeApp, Picker, Prompt


class TerminalUITests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    async def wait_idle(self, app, pilot):
        for _ in range(300):
            await pilot.pause(0.04)
            if not app.busy:
                return
        self.fail("UI task did not finish")

    async def test_keyboard_palette_history_multiline_and_responsive_layout(self):
        app = ForgeApp(self.root)
        async with app.run_test(size=(140, 46)) as pilot:
            prompt = app.query_one(Prompt)
            prompt.load_text("/hel")
            await pilot.press("tab")
            self.assertEqual(prompt.text, "/help ")
            await pilot.press("enter")
            await pilot.pause()
            self.assertTrue(any("在终端完成设计闭环" in m["content"] for m in app.session.messages))
            await pilot.press("up")
            self.assertEqual(prompt.text, "/help")
            prompt.load_text("line")
            prompt.move_cursor(prompt.document.end)
            await pilot.press("shift+enter")
            self.assertIn("\n", prompt.text)
            await pilot.press("ctrl+p")
            self.assertIsInstance(app.screen, Picker)
            await pilot.press("escape", "shift+tab")
            self.assertEqual(app.settings.mode, "plan")
            await pilot.resize_terminal(78, 28)
            self.assertFalse(app.query_one("#inspector").display)
            self.assertFalse(app.query_one("#sidebar").display)
            self.assertGreater(app.query_one(Prompt).size.width, 25)

    async def test_connection_key_is_not_written_and_resume_restores_conversation(self):
        app = ForgeApp(self.root)
        async with app.run_test(size=(140, 46)) as pilot:
            await app.submit_command("/connect")
            await pilot.pause()
            self.assertIsInstance(app.screen, Connection)
            app.screen.query_one("#api-key", Input).value = "test-credential-do-not-persist"
            app.screen.query_one("#model", Input).value = "test-model"
            await pilot.click("#connection-save")
            await pilot.pause()
            self.assertEqual(app.settings.model, "test-model")
            await app.add_message("user", "a retained message")
            old_id = app.session.id
            await app.new_session()
            await app.load_session(old_id)
            self.assertIn("a retained message", app.session.messages[-1]["content"])
            for path in (self.root / ".fpga-agent").rglob("*.json"):
                self.assertNotIn("test-credential-do-not-persist", path.read_text(encoding="utf-8"))

    async def test_plan_mode_defers_actual_creation_until_run(self):
        app = ForgeApp(self.root)
        async with app.run_test(size=(120, 40)) as pilot:
            await app.submit_command("/plan")
            await app.submit_command("/init demo")
            self.assertFalse((self.root / "demo/project.json").exists())
            self.assertIsNotNone(app.pending)
            await app.submit_command("/run")
            await self.wait_idle(app, pilot)
            self.assertTrue((self.root / "demo/project.json").is_file())
            self.assertEqual(app.selected.name, "demo")

    async def test_real_model_transport_to_ui_tool_to_icarus(self):
        local_iverilog = Path(__file__).resolve().parents[1] / ".tools/icarus/bin/iverilog.exe"
        if not shutil.which("iverilog") and not local_iverilog.is_file():
            self.skipTest("Icarus is required for the integration test")
        captured = []
        payload = {"message": "运行独立仿真。", "action": "verify", "arguments": {"project": "", "brief": "", "architecture": "multi", "full": False, "simulation_only": False}}

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                captured.append(json.loads(self.rfile.read(int(self.headers["Content-Length"]))))
                body = json.dumps({"output_text": json.dumps(payload, ensure_ascii=False)}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        project = create_project("demo", self.root / "demo")
        app = ForgeApp(self.root)
        app.settings.base_url = f"http://127.0.0.1:{server.server_port}/v1"
        app.extra_env["OPENAI_API_KEY"] = "integration-test-not-a-real-key"
        async with app.run_test(size=(140, 46)) as pilot:
            await app.select_project(project)
            app.query_one(Prompt).load_text("请检查当前工程")
            await pilot.press("enter")
            await self.wait_idle(app, pilot)
            report = read_json(project / "reports/simulation.json", {})
            self.assertEqual(report.get("status"), "pass", app.tail)
            self.assertTrue(captured)
            self.assertTrue(any(m["role"] == "tool" and "通过" in m["content"] for m in app.session.messages))
            for path in app.workspace.state.rglob("*.json"):
                self.assertNotIn("integration-test-not-a-real-key", path.read_text(encoding="utf-8"))

    async def test_failed_tool_is_visible_and_does_not_report_pass(self):
        app = ForgeApp(self.root)
        async with app.run_test(size=(120, 40)) as pilot:
            import sys
            app.start_plan(TaskPlan("intentional failure", [[sys.executable, "-c", "print('tool rejected input');raise SystemExit(9)"]]))
            await self.wait_idle(app, pilot)
            self.assertTrue(any("exit 9" in m["content"] for m in app.session.messages))
            self.assertFalse(app.busy)

    async def test_attachment_picker_and_new_session_input_history(self):
        project = create_project("demo", self.root / "demo")
        app = ForgeApp(self.root)
        async with app.run_test(size=(120, 40)) as pilot:
            await app.select_project(project)
            prompt = app.query_one(Prompt)
            prompt.load_text("检查 @rtl/")
            await pilot.press("tab")
            self.assertIsInstance(app.screen, Picker)
            app.screen.query_one(Input).value = "rtl/"
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()
            self.assertIn("@rtl/hx1p35a_heartbeat.v", prompt.text)
            prompt.remember("/help")
            await app.new_session()
            self.assertEqual(prompt.input_history, [])

    async def test_natural_local_action_respects_plan_mode(self):
        project = create_project("demo", self.root / "demo")
        app = ForgeApp(self.root)
        async with app.run_test(size=(120, 40)):
            await app.select_project(project)
            app.settings.mode = "plan"
            await app.submit_command("运行仿真")
            self.assertIsNotNone(app.pending)
            self.assertFalse(app.busy)
            self.assertFalse((project / "reports/simulation.json").exists())
